class Member < ApplicationRecord
	belongs_to :team
end
