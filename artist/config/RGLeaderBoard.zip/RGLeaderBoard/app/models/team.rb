class Team < ApplicationRecord
	has_many :members
end
